"""
Cog Cours - Consultation et recherche de cours
Ambulance Assistance Marseille - Bot Formations
"""

import discord
from discord.ext import commands
from discord import app_commands
import json
import os

from utils.course_generator import CourseGenerator
from config import FORMATION_COLORS, FORMATION_EMOJIS, TAGS_COURS


class CoursesCog(commands.Cog):
    """Commandes de consultation des cours"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.generator = CourseGenerator()
        self._load_formations()

    def _load_formations(self):
        """Charge les données de formations"""
        data_dir = "data"
        formations = {
            "DEA": "dea.json",
            "AA": "auxiliaire.json",
            "IPA": "ipa.json",
            "IADE": "iade.json",
            "IDE": "ide_urgence.json",
        }
        for code, filename in formations.items():
            filepath = os.path.join(data_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.generator.load_formation(code, data)

    @app_commands.command(name="rechercher_cours", description="Rechercher un cours par mot-clé")
    async def rechercher_cours(self, interaction: discord.Interaction, mot_cle: str):
        """Recherche un cours par mot-clé dans tous les référentiels"""
        await interaction.response.defer(ephemeral=True)

        results = []
        mot_cle_lower = mot_cle.lower()

        for code, data in self.generator.formations_data.items():
            emoji = FORMATION_EMOJIS.get(code, "📚")
            for module in data.get("modules", []):
                # Recherche dans le titre du module
                if mot_cle_lower in module["titre"].lower():
                    results.append({
                        "formation": code,
                        "emoji": emoji,
                        "type": "module",
                        "id": module["id"],
                        "titre": module["titre"],
                    })

                for comp in module.get("competences", []):
                    if mot_cle_lower in comp["titre"].lower():
                        results.append({
                            "formation": code,
                            "emoji": emoji,
                            "type": "competence",
                            "id": comp["id"],
                            "module_id": module["id"],
                            "titre": comp["titre"],
                        })

                    for apt in comp.get("aptitudes", []):
                        if mot_cle_lower in apt["titre"].lower():
                            results.append({
                                "formation": code,
                                "emoji": emoji,
                                "type": "aptitude",
                                "id": apt["id"],
                                "module_id": module["id"],
                                "titre": apt["titre"],
                            })

                        for methode in apt.get("methodes", []):
                            if mot_cle_lower in methode.lower():
                                results.append({
                                    "formation": code,
                                    "emoji": emoji,
                                    "type": "methode",
                                    "titre": methode,
                                    "aptitude_id": apt["id"],
                                    "module_id": module["id"],
                                })

        if not results:
            await interaction.followup.send(
                f"🔍 Aucun résultat pour **{mot_cle}**.\n"
                "Essayez avec un autre terme ou utilisez `/liste_formations`.",
                ephemeral=True
            )
            return

        # Construire l'embed de résultats
        embed = discord.Embed(
            title=f"🔍 Résultats de recherche : \"{mot_cle}\"",
            description=f"**{len(results)}** résultat(s) trouvé(s)",
            color=0x3498DB,
        )

        # Grouper par formation
        by_formation = {}
        for r in results:
            key = r["formation"]
            if key not in by_formation:
                by_formation[key] = []
            by_formation[key].append(r)

        for code, items in by_formation.items():
            emoji = FORMATION_EMOJIS.get(code, "📚")
            value = ""
            for item in items[:10]:  # Max 10 par formation
                type_icon = {"module": "📚", "competence": "🎯", "aptitude": "💪", "methode": "📋"}.get(item["type"], "📄")
                value += f"{type_icon} `{item['id']}` {item['titre'][:60]}\n"
            if len(items) > 10:
                value += f"_...et {len(items) - 10} autres résultats_\n"
            embed.add_field(
                name=f"{emoji} {code}",
                value=value[:1024],
                inline=False
            )

        embed.set_footer(text="Utilisez /envoyer_cours pour générer un cours détaillé")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="cours_disponibles", description="Voir tous les cours disponibles pour une formation")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
        ]
    )
    async def cours_disponibles(self, interaction: discord.Interaction,
                                 formation: app_commands.Choice[str]):
        """Liste tous les cours disponibles avec tags"""
        formation_code = formation.value
        formation_data = self.generator.formations_data.get(formation_code)

        if not formation_data:
            await interaction.response.send_message("❌ Formation introuvable.", ephemeral=True)
            return

        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        emoji = FORMATION_EMOJIS.get(formation_code, "📚")

        # Construire la vue
        pages = []
        current_page = discord.Embed(
            title=f"{emoji} Cours disponibles — {formation_data.get('nom', formation_code)}",
            color=color,
        )

        field_count = 0
        for module in formation_data.get("modules", []):
            tags = self.generator.get_tags_for_course(
                formation_code, module,
                module["competences"][0] if module.get("competences") else {"titre": ""})
            tags_str = " ".join([f"`{t}`" for t in tags])

            value = f"⏱️ {module.get('heures', '?')}h\n{tags_str}\n"
            for comp in module.get("competences", []):
                value += f"  🎯 `{comp['id']}` {comp['titre'][:50]}\n"
                for apt in comp.get("aptitudes", []):
                    value += f"    💪 `{apt['id']}` {apt['titre'][:40]}\n"
                    for m in apt.get("methodes", []):
                        value += f"      📋 {m}\n"

            # Si la page est trop pleine, créer une nouvelle
            if field_count >= 24 or len(value) > 900:
                if current_page.fields:
                    pages.append(current_page)
                current_page = discord.Embed(
                    title=f"{emoji} Cours disponibles — {formation_data.get('nom')} (suite)",
                    color=color,
                )
                field_count = 0

            current_page.add_field(
                name=f"📚 {module['id']} — {module['titre'][:70]}",
                value=value[:1024],
                inline=False
            )
            field_count += 1

        if current_page.fields:
            pages.append(current_page)

        # Envoyer la première page
        if pages:
            await interaction.response.send_message(embed=pages[0])
            # Si plusieurs pages, envoyer les suivantes
            for page in pages[1:3]:  # Max 3 pages
                await interaction.followup.send(embed=page)
            if len(pages) > 3:
                await interaction.followup.send(f"_...et {len(pages) - 3} autres pages. Utilisez la recherche pour cibler._")
        else:
            await interaction.response.send_message("Aucun cours disponible pour cette formation.")

    @app_commands.command(name="quiz", description="Quiz rapide sur un cours")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
        ]
    )
    async def quiz(self, interaction: discord.Interaction,
                    formation: app_commands.Choice[str],
                    module_id: str = ""):
        """Lance un quiz rapide sur un module"""
        formation_code = formation.value
        formation_data = self.generator.formations_data.get(formation_code)

        if not formation_data:
            await interaction.response.send_message("❌ Formation introuvable.", ephemeral=True)
            return

        # Trouver le module
        module_data = None
        if module_id:
            for m in formation_data.get("modules", []):
                if m["id"].upper() == module_id.upper():
                    module_data = m
                    break
        else:
            import random
            module_data = random.choice(formation_data.get("modules", []))

        if not module_data:
            await interaction.response.send_message("❌ Module introuvable.", ephemeral=True)
            return

        # Générer des questions basées sur le contenu
        questions = self._generate_questions(formation_code, module_data)

        if not questions:
            await interaction.response.send_message("❌ Impossible de générer un quiz pour ce module.", ephemeral=True)
            return

        # Afficher le quiz
        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        embed = discord.Embed(
            title=f"🧠 Quiz — {module_data['titre']}",
            description=f"**Formation :** {formation_data.get('nom', formation_code)}\n"
                       f"**{len(questions)}** question(s)\n\n"
                       "Répondez avec les boutons ci-dessous !",
            color=color,
        )

        # Créer les boutons de réponse
        view = QuizView(questions, formation_code, module_data["id"], interaction.user.id)
        await interaction.response.send_message(embed=embed, view=view)

    def _generate_questions(self, formation_code: str, module_data: dict) -> list:
        """Génère des questions de quiz basées sur le contenu du module"""
        import random

        questions = []

        for comp in module_data.get("competences", []):
            for apt in comp.get("aptitudes", []):
                # Question sur les méthodes
                methodes = apt.get("methodes", [])
                if methodes:
                    # Question : quelle méthode fait partie de cette aptitude ?
                    bonne_reponse = random.choice(methodes)
                    autres = [m for m in methodes if m != bonne_reponse]

                    question = {
                        "question": f"Dans l'aptitude **{apt['titre'][:50]}**, quelle méthode est enseignée ?",
                        "options": [bonne_reponse] + autres[:3] if len(autres) >= 3 else [bonne_reponse] + autres,
                        "bonne_reponse": bonne_reponse,
                    }
                    questions.append(question)

                # Question sur le titre de l'aptitude
                question_apt = {
                    "question": f"Que doit-on maîtriser dans l'aptitude `{apt['id']}` ?",
                    "options": [
                        apt["titre"],
                        "Rien de spécifique",
                        "Uniquement la théorie",
                        "Uniquement la pratique",
                    ][:4],
                    "bonne_reponse": apt["titre"],
                }
                questions.append(question_apt)

        return random.sample(questions, min(5, len(questions))) if questions else []


class QuizView(discord.ui.View):
    """Vue interactive pour le quiz"""

    def __init__(self, questions: list, formation_code: str, module_id: str, user_id: int):
        super().__init__(timeout=120)
        self.questions = questions
        self.formation_code = formation_code
        self.module_id = module_id
        self.user_id = user_id
        self.current_question = 0
        self.score = 0
        self._update_buttons()

    def _update_buttons(self):
        """Met à jour les boutons pour la question courante"""
        self.clear_items()

        if self.current_question >= len(self.questions):
            return

        q = self.questions[self.current_question]
        for i, option in enumerate(q["options"]):
            button = discord.ui.Button(
                label=option[:80],
                style=discord.ButtonStyle.primary,
                custom_id=f"quiz_option_{i}",
            )
            button.callback = self._make_callback(i)
            self.add_item(button)

    def _make_callback(self, option_index: int):
        """Crée un callback pour un bouton d'option"""
        async def callback(interaction: discord.Interaction):
            q = self.questions[self.current_question]
            chosen = q["options"][option_index]

            if chosen == q["bonne_reponse"]:
                self.score += 1
                result = f"✅ **Correct !** La bonne réponse était : {chosen}"
            else:
                result = f"❌ **Incorrect.** La bonne réponse était : **{q['bonne_reponse']}**"

            self.current_question += 1

            if self.current_question >= len(self.questions):
                # Quiz terminé
                embed = discord.Embed(
                    title="🏆 Quiz terminé !",
                    description=f"**Score :** {self.score}/{len(self.questions)}\n\n"
                               f"{'🎉 Excellent !' if self.score == len(self.questions) else ''}"
                               f"{'👍 Bien joué !' if self.score > len(self.questions) * 0.7 else ''}"
                               f"{'📖 Continuez à réviser !' if self.score <= len(self.questions) * 0.5 else ''}",
                    color=0x2ECC71 if self.score > len(self.questions) * 0.5 else 0xE74C3C,
                )
                await interaction.response.edit_message(embed=embed, view=None)

                # Enregistrer le score
                if hasattr(interaction.client, 'db'):
                    await interaction.client.db.record_cours_suivi(
                        user_id=self.user_id,
                        formation_code=self.formation_code,
                        module_id=self.module_id,
                        cours_type="quiz",
                    )
            else:
                embed = discord.Embed(
                    title=f"🧠 Question {self.current_question + 1}/{len(self.questions)}",
                    description=f"{result}\n\n**Question suivante :**\n{self.questions[self.current_question]['question']}",
                    color=0x3498DB,
                )
                self._update_buttons()
                await interaction.response.edit_message(embed=embed, view=self)

        return callback


async def setup(bot: commands.Bot):
    await bot.add_cog(CoursesCog(bot))
