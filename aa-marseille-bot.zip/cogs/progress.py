"""
Cog Progression - Suivi de la progression des formations
Ambulance Assistance Marseille - Bot Formations
"""

import discord
from discord.ext import commands
from discord import app_commands
import json
import os

from config import FORMATION_COLORS, FORMATION_EMOJIS, NIVEAUX


class ProgressionCog(commands.Cog):
    """Commandes de suivi de progression"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="valider", description="Marquer un cours comme suivi")
    async def valider(self, interaction: discord.Interaction,
                       formation_code: str,
                       module_id: str,
                       note: str = ""):
        """Mark a course as completed"""
        user_id = interaction.user.id
        username = interaction.user.display_name

        # Register user if needed
        await self.bot.db.register_user(user_id, username, formation_code.upper())

        # Record course completion
        await self.bot.db.record_cours_suivi(
            user_id=user_id,
            formation_code=formation_code.upper(),
            module_id=module_id.upper(),
            cours_type="suivi",
        )

        embed = discord.Embed(
            title="✅ Cours validé !",
            description=f"**{interaction.user.display_name}** a validé le module `{module_id}` "
                       f"de la formation `{formation_code.upper()}`.\n\n"
                       f"{'📝 Note : ' + note if note else ''}",
            color=0x2ECC71,
        )
        embed.set_footer(text="Continuez votre progression ! /ma_progression pour voir votre avancement.")

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ma_progression", description="Voir ma progression dans une formation")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
            app_commands.Choice(name="📖 Toutes", value="ALL"),
        ]
    )
    async def ma_progression(self, interaction: discord.Interaction,
                              formation: app_commands.Choice[str] = None):
        """Affiche la progression de l'utilisateur"""
        user_id = interaction.user.id
        formation_code = formation.value if formation else None

        if formation_code == "ALL":
            formation_code = None

        progression = await self.bot.db.get_user_progression(
            user_id, formation_code if formation_code else None)

        if not progression:
            await interaction.response.send_message(
                "📊 Vous n'avez encore validé aucun cours.\n"
                "Utilisez `/valider` ou suivez les cours envoyés par les formateurs.",
                ephemeral=True
            )
            return

        # Construire l'embed de progression
        color = FORMATION_COLORS.get(formation_code, 0x3498DB) if formation_code else 0x3498DB

        embed = discord.Embed(
            title="📊 Ma Progression",
            description=f"Progression de **{interaction.user.display_name}**",
            color=color,
        )

        # Grouper par formation
        by_formation = {}
        for p in progression:
            fc = p.get("formation_code", "N/A")
            if fc not in by_formation:
                by_formation[fc] = []
            by_formation[fc].append(p)

        for fc, items in by_formation.items():
            emoji = FORMATION_EMOJIS.get(fc, "📚")
            modules_valides = set(item["module_id"] for item in items)
            nb_cours = len(items)

            embed.add_field(
                name=f"{emoji} {fc}",
                value=f"**{nb_cours}** cours suivi(s)\n"
                      f"**{len(modules_valides)}** module(s) validé(s)\n"
                      f"Modules : {', '.join(f'`{m}`' for m in modules_valides)}",
                inline=False
            )

        # Barre de progression globale
        total_modules = 0
        validated_modules = set()
        # Estimation : charger les données pour calculer le total
        for fc in by_formation:
            data_file = {
                "DEA": "dea.json", "AA": "auxiliaire.json",
                "IPA": "ipa.json", "IADE": "iade.json", "IDE": "ide_urgence.json"
            }.get(fc)
            if data_file:
                filepath = os.path.join("data", data_file)
                if os.path.exists(filepath):
                    with open(filepath, "r") as f:
                        data = json.load(f)
                        nb = len(data.get("modules", []))
                        total_modules += nb

        validated_count = len(set(p["module_id"] for p in progression))
        percent = int((validated_count / total_modules) * 100) if total_modules > 0 else 0

        embed.add_field(
            name="📈 Progression globale",
            value=f"{'█' * (percent // 10)}{'░' * (10 - percent // 10)} {percent}%\n"
                  f"{validated_count}/{total_modules} modules validés",
            inline=False
        )

        embed.set_footer(text="Ambulance Assistance Marseille — Suivi Formation")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="stats_formation", description="[ADMIN] Statistiques d'une formation")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
        ]
    )
    async def stats_formation(self, interaction: discord.Interaction,
                               formation: app_commands.Choice[str]):
        """Affiche les statistiques d'une formation"""
        formation_code = formation.value
        stats = await self.bot.db.get_stats_formation(formation_code)

        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        emoji = FORMATION_EMOJIS.get(formation_code, "📚")

        embed = discord.Embed(
            title=f"{emoji} Statistiques — {formation_code}",
            color=color,
        )
        embed.add_field(name="👥 Inscrits", value=str(stats.get("inscrits", 0)), inline=True)
        embed.add_field(name="📚 Cours envoyés", value=str(stats.get("cours_envoyes", 0)), inline=True)

        embed.set_footer(text="Ambulance Assistance Marseille")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="inscription", description="S'inscrire à une formation")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA - Ambulancier", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire Ambulancier", value="AA"),
            app_commands.Choice(name="⚕️ IPA - Soins d'Urgence", value="IPA"),
            app_commands.Choice(name="💉 IADE - Anesthésiste", value="IADE"),
            app_commands.Choice(name="🩺 IDE - Soins d'Urgence", value="IDE"),
        ]
    )
    async def inscription(self, interaction: discord.Interaction,
                           formation: app_commands.Choice[str]):
        """S'inscrire à une formation"""
        await self.bot.db.register_user(
            interaction.user.id,
            interaction.user.display_name,
            formation.value
        )

        emoji = FORMATION_EMOJIS.get(formation.value, "📚")
        embed = discord.Embed(
            title=f"{emoji} Inscription confirmée !",
            description=f"**{interaction.user.display_name}** est maintenant inscrit(e) à la formation "
                       f"**{formation.name}**.\n\n"
                       "Vous recevrez les cours dans le canal dédié. "
                       "Utilisez `/ma_progression` pour suivre votre avancement.",
            color=FORMATION_COLORS.get(formation.value, 0x3498DB),
        )
        embed.set_footer(text="Ambulance Assistance Marseille — Service Formation")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="leaderboard", description="Classement des apprenants")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
        ]
    )
    async def leaderboard(self, interaction: discord.Interaction,
                           formation: app_commands.Choice[str]):
        """Affiche le classement des apprenants par progression"""
        formation_code = formation.value

        # Récupérer tous les cours envoyés pour cette formation
        cours_envoyes = await self.bot.db.get_cours_envoyes(formation_code)

        # Récupérer les progressions de tous les utilisateurs
        # (Simplifié — en production on ferait une requête SQL agrégée)
        embed = discord.Embed(
            title=f"🏆 Classement — {formation_code}",
            description="Top apprenants par nombre de cours validés",
            color=FORMATION_COLORS.get(formation_code, 0x3498DB),
        )

        # Compter les cours validés par utilisateur via la BDD
        # (Le leaderboard complet sera implémenté avec une requête SQL agrégée)

        # En attendant, afficher un message informatif
        embed.add_field(
            name="📊 Statistiques",
            value=f"**{len(cours_envoyes)}** cours envoyés au total\n"
                  "Le classement complet sera disponible après plus de validations.",
            inline=False
        )

        embed.set_footer(text="Ambulance Assistance Marseille")
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(ProgressionCog(bot))
