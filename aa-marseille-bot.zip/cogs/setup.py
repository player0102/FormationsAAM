"""
Cog Setup - Configuration initiale du serveur Discord
Ambulance Assistance Marseille - Bot Formations
"""

import discord
from discord.ext import commands
from discord import app_commands
from config import FORMATION_COLORS, FORMATION_EMOJIS, TAGS_COURS


class SetupCog(commands.Cog):
    """Commandes de configuration initiale du serveur"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="setup_serveur", description="[ADMIN] Configurer le serveur pour les formations")
    async def setup_serveur(self, interaction: discord.Interaction):
        """Configure le serveur Discord avec les canaux et rôles nécessaires"""

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Permissions Administrateur requises.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild
        embeds = []

        # Créer la catégorie Formation
        category = discord.utils.get(guild.categories, name="📚 FORMATIONS")
        if not category:
            category = await guild.create_category("📚 FORMATIONS")
            embeds.append("✅ Catégorie '📚 FORMATIONS' créée")

        # Créer les canaux par formation
        formations_channels = {
            "🚑-dea": "Formation DEA — Ambulancier",
            "🏥-auxiliaire": "Formation Auxiliaire Ambulancier",
            "⚕️-ipa": "Formation IPA — Soins d'Urgence",
            "💉-iade": "Formation IADE — Anesthésiste",
            "🩺-ide-urgence": "Formation IDE — Soins d'Urgence",
        }

        for channel_name, channel_topic in formations_channels.items():
            existing = discord.utils.get(guild.text_channels, name=channel_name)
            if not existing:
                channel = await guild.create_text_channel(
                    name=channel_name,
                    category=category,
                    topic=channel_topic
                )
                embeds.append(f"✅ Canal #{channel_name} créé")

        # Créer le canal général de formation
        general = discord.utils.get(guild.text_channels, name="📢-annonces-formations")
        if not general:
            await guild.create_text_channel(
                name="📢-annonces-formations",
                category=category,
                topic="Annonces générales et nouveaux cours"
            )
            embeds.append("✅ Canal annonces créé")

        # Créer les rôles de formation
        formation_roles = {
            "🚑 DEA": "Apprenant DEA",
            "🏥 Auxiliaire": "Apprenant Auxiliaire",
            "⚕️ IPA": "Apprenant IPA",
            "💉 IADE": "Apprenant IADE",
            "🩺 IDE Urgence": "Apprenant IDE",
            "👨‍🏫 Formateur": "Formateur",
        }

        for role_name, _ in formation_roles.items():
            existing = discord.utils.get(guild.roles, name=role_name)
            if not existing:
                color = 0x3498DB
                for code, c in FORMATION_COLORS.items():
                    if code in role_name:
                        color = c
                        break
                await guild.create_role(name=role_name, color=color)
                embeds.append(f"✅ Rôle '{role_name}' créé")

        # Créer les tags du forum si applicable
        summary = "\n".join(embeds)
        result_embed = discord.Embed(
            title="🛠️ Configuration du serveur terminée",
            description=summary or "Tout est déjà configuré !",
            color=0x2ECC71,
        )
        result_embed.set_footer(text="Ambulance Assistance Marseille")

        await interaction.followup.send(embed=result_embed, ephemeral=True)

    @app_commands.command(name="creer_forum_cours", description="[ADMIN] Créer un forum avec tags pour les cours")
    async def creer_forum_cours(self, interaction: discord.Interaction,
                                 nom: str = "📚-cours-formations"):
        """Crée un canal forum avec les tags de cours"""

        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Permissions requises.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild

        # Vérifier si le forum existe déjà
        existing = discord.utils.get(guild.channels, name=nom)
        if existing:
            await interaction.followup.send(f"⚠️ Le forum #{nom} existe déjà.", ephemeral=True)
            return

        # Créer le forum
        try:
            forum = await guild.create_forum(
                name=nom,
                topic="Cours de formation — Ambulance Assistance Marseille\n"
                      "Les cours sont organisés par tags. Utilisez la recherche pour trouver un cours.",
            )

            # Créer les tags disponibles
            available_tags = []
            for tag_code, tag_info in TAGS_COURS.items():
                tag = discord.ForumTag(name=f"{tag_info['emoji']} {tag_info['label']}", emoji=None)
                available_tags.append(tag)

            # Ajouter les tags de formation
            for code, emoji in FORMATION_EMOJIS.items():
                tag = discord.ForumTag(name=f"{emoji} {code}", emoji=None)
                available_tags.append(tag)

            await interaction.followup.send(
                f"✅ Forum **#{nom}** créé avec succès !\n\n"
                f"**Tags disponibles :**\n"
                + "\n".join([f"• `{TAGS_COURS[t]['emoji']} {TAGS_COURS[t]['label']}`" for t in TAGS_COURS])
                + "\n\n" + "\n".join([f"• `{emoji} {code}`" for code, emoji in FORMATION_EMOJIS.items()]),
                ephemeral=True
            )
        except Exception as e:
            await interaction.followup.send(f"❌ Erreur : {e}", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(SetupCog(bot))
