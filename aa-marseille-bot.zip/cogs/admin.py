"""
Cog Admin - Commandes d'administration
Ambulance Assistance Marseille - Bot Formations
"""

import discord
from discord.ext import commands
from discord import app_commands
import json
import os
from typing import Optional

from utils.course_generator import CourseGenerator
from config import FORMATION_COLORS, FORMATION_EMOJIS, TYPE_EMOJIS, TAGS_COURS, NIVEAUX


class AdminCog(commands.Cog):
    """Commandes admin pour gérer les cours et formations"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.generator = CourseGenerator()
        self._load_formations()

    def _load_formations(self):
        """Charge toutes les données de formations"""
        data_dir = "data"
        formations = {
            "DEA": "dea.json",
            "AA": "auxiliaire.json",
            "IPA": "ipa.json",
            "IADE": "iade.json",
            "IDE": "ide_urgence.json",
        }
        for code, filename in formations.items():
            filepath = os.path.join(data_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.generator.load_formation(code, data)

    def _is_admin(self, interaction: discord.Interaction) -> bool:
        """Vérifie si l'utilisateur est admin ou formateur"""
        if interaction.user.guild_permissions.administrator:
            return True
        # Vérifier les rôles configurés
        from config import ADMIN_ROLE_IDS, FORMATEUR_ROLE_IDS
        allowed = ADMIN_ROLE_IDS + FORMATEUR_ROLE_IDS
        user_role_ids = [role.id for role in interaction.user.roles]
        return any(role_id in user_role_ids for role_id in allowed if role_id > 0)

    @app_commands.command(name="envoyer_cours", description="[ADMIN] Envoyer un cours dans un fil dédié")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA - Ambulancier", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire Ambulancier", value="AA"),
            app_commands.Choice(name="⚕️ IPA - Soins d'Urgence", value="IPA"),
            app_commands.Choice(name="💉 IADE - Anesthésiste", value="IADE"),
            app_commands.Choice(name="🩺 IDE - Soins d'Urgence", value="IDE"),
        ],
        type_cours=[
            app_commands.Choice(name="📋 Méthode (fiche pratique)", value="methode"),
            app_commands.Choice(name="💪 Aptitude", value="aptitude"),
            app_commands.Choice(name="🎯 Compétence (module complet)", value="competence"),
        ]
    )
    async def envoyer_cours(self, interaction: discord.Interaction,
                             formation: app_commands.Choice[str],
                             type_cours: app_commands.Choice[str],
                             module_id: str,
                             competence_id: str = "",
                             aptitude_id: str = "",
                             methode_nom: str = "",
                             notes_formateur: str = ""):
        """Envoie un cours généré par le bot dans un fil avec tags"""

        if not self._is_admin(interaction):
            await interaction.response.send_message(
                "❌ Vous n'avez pas les permissions nécessaires.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        formation_code = formation.value
        cours_type = type_cours.value

        # Récupérer les données de la formation
        formation_data = self.generator.formations_data.get(formation_code)
        if not formation_data:
            await interaction.followup.send(f"❌ Formation {formation_code} introuvable.")
            return

        # Trouver le module
        module_data = None
        for m in formation_data.get("modules", []):
            if m["id"].upper() == module_id.upper():
                module_data = m
                break

        if not module_data:
            await interaction.followup.send(f"❌ Module `{module_id}` introuvable dans {formation_code}.")
            return

        # Générer le cours selon le type
        course_content = ""
        thread_title = ""

        if cours_type == "methode":
            # Trouver la compétence et l'aptitude
            competence_data = None
            aptitude_data = None
            for c in module_data.get("competences", []):
                if competence_id and c["id"].upper() != competence_id.upper():
                    continue
                for a in c.get("aptitudes", []):
                    if aptitude_id and a["id"].upper() != aptitude_id.upper():
                        continue
                    if methode_nom.lower() in [m.lower() for m in a.get("methodes", [])]:
                        competence_data = c
                        aptitude_data = a
                        break
                if aptitude_data:
                    break

            if not aptitude_data or not methode_nom:
                await interaction.followup.send("❌ Méthode introuvable. Vérifiez les IDs fournis.")
                return

            course_content = self.generator.generate_course_for_methode(
                formation_code, module_data, competence_data, aptitude_data,
                methode_nom, notes_formateur)
            thread_title = f"📋 {methode_nom} | {formation_code} {module_data['id']}"

        elif cours_type == "aptitude":
            competence_data = None
            aptitude_data = None
            for c in module_data.get("competences", []):
                if competence_id and c["id"].upper() != competence_id.upper():
                    continue
                for a in c.get("aptitudes", []):
                    if a["id"].upper() == aptitude_id.upper():
                        competence_data = c
                        aptitude_data = a
                        break
                if aptitude_data:
                    break

            if not aptitude_data:
                await interaction.followup.send("❌ Aptitude introuvable. Vérifiez les IDs.")
                return

            course_content = self.generator.generate_course_for_aptitude(
                formation_code, module_data, competence_data, aptitude_data,
                notes_formateur)
            thread_title = f"💪 {aptitude_data['titre']} | {formation_code} {module_data['id']}"

        elif cours_type == "competence":
            competence_data = None
            for c in module_data.get("competences", []):
                if c["id"].upper() == competence_id.upper():
                    competence_data = c
                    break

            if not competence_data:
                # Si pas d'ID précisé, prendre la première compétence
                if module_data.get("competences"):
                    competence_data = module_data["competences"][0]
                else:
                    await interaction.followup.send("❌ Compétence introuvable.")
                    return

            course_content = self.generator.generate_course_for_competence(
                formation_code, module_data, competence_data, notes_formateur)
            thread_title = f"🎯 {competence_data['titre']} | {formation_code} {module_data['id']}"

        # Déterminer les tags
        competence_for_tags = competence_data if 'competence_data' in dir() else None
        if competence_for_tags is None and module_data.get("competences"):
            competence_for_tags = module_data["competences"][0]

        tags = self.generator.get_tags_for_course(
            formation_code, module_data, competence_for_tags) if competence_for_tags else [formation_code.lower()]

        # Créer l'embed
        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        emoji = FORMATION_EMOJIS.get(formation_code, "📚")
        embed = discord.Embed(
            title=f"{emoji} {thread_title}",
            description=course_content[:4000] if len(course_content) > 4000 else course_content,
            color=color,
        )
        embed.set_footer(text=f"Ambulance Assistance Marseille | {formation_data.get('nom', '')}")
        embed.set_author(name=f"Cours envoyé par {interaction.user.display_name}",
                        icon_url=interaction.user.display_avatar.url if interaction.user.display_avatar else None)

        # Ajouter les tags en description
        tags_text = " ".join([f"`{TAGS_COURS.get(t, {}).get('emoji', '🏷️')} {t}`" for t in tags])
        embed.add_field(name="🏷️ Tags", value=tags_text or "`formation`", inline=False)

        # Créer le fil (thread)
        channel = interaction.channel

        # Envoyer le message initial
        if isinstance(channel, discord.TextChannel):
            # Envoyer le message
            msg = await channel.send(embed=embed)

            # Créer un thread attaché au message
            thread = await msg.create_thread(
                name=thread_title[:100],
                auto_archive_duration=10080,  # 7 jours
            )

            # Envoyer un message de bienvenue dans le thread
            welcome_embed = discord.Embed(
                title=f"💬 Discussion — {thread_title}",
                description=(
                    "Posez vos questions sur ce cours ici.\n\n"
                    "**Commandes disponibles :**\n"
                    "`/quiz` — Tester vos connaissances\n"
                    "`/valider` — Marquer ce cours comme suivi\n"
                    "`/ressource` — Ajouter une ressource complémentaire"
                ),
                color=color,
            )
            await thread.send(embed=welcome_embed)

            # Si le cours est trop long, envoyer en plusieurs parties
            if len(course_content) > 4000:
                chunks = self._split_content(course_content, 2000)
                for i, chunk in enumerate(chunks):
                    if i == 0:
                        continue  # déjà dans l'embed
                    part_embed = discord.Embed(
                        description=chunk,
                        color=color,
                    )
                    part_embed.set_footer(text=f"Partie {i+1}/{len(chunks)}")
                    await thread.send(embed=part_embed)

            # Enregistrer en base
            await self.bot.db.record_cours_envoye(
                admin_id=interaction.user.id,
                formation_code=formation_code,
                module_id=module_id,
                cours_type=cours_type,
                thread_id=thread.id,
                message_id=msg.id,
                channel_id=channel.id,
                competence_id=competence_id or None,
                aptitude_id=aptitude_id or None,
                methode=methode_nom or None,
                extra_notes=notes_formateur or None,
            )

            await interaction.followup.send(
                f"✅ Cours envoyé avec succès !\n"
                f"**Fil créé :** {thread.mention}\n"
                f"**Formation :** {formation_data.get('nom', formation_code)}\n"
                f"**Tags :** {tags_text}",
                ephemeral=True
            )
        else:
            await interaction.followup.send("❌ Cette commande doit être utilisée dans un canal textuel.", ephemeral=True)

    @app_commands.command(name="envoyer_tout_module", description="[ADMIN] Envoyer tous les cours d'un module complet")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
        ]
    )
    async def envoyer_tout_module(self, interaction: discord.Interaction,
                                    formation: app_commands.Choice[str],
                                    module_id: str,
                                    notes_formateur: str = ""):
        """Envoie tous les cours d'un module dans un fil unique"""

        if not self._is_admin(interaction):
            await interaction.response.send_message("❌ Permissions insuffisantes.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        formation_code = formation.value
        formation_data = self.generator.formations_data.get(formation_code)
        if not formation_data:
            await interaction.followup.send("❌ Formation introuvable.")
            return

        module_data = None
        for m in formation_data.get("modules", []):
            if m["id"].upper() == module_id.upper():
                module_data = m
                break

        if not module_data:
            await interaction.followup.send(f"❌ Module `{module_id}` introuvable.")
            return

        # Générer un cours global pour tout le module
        all_content = []
        all_content.append(f"# 📚 {module_data['titre']}")
        all_content.append(f"**Formation :** {formation_data.get('nom', formation_code)}")
        all_content.append(f"**Durée :** {module_data.get('heures', '?')} heures")
        all_content.append("---")

        for comp in module_data.get("competences", []):
            course = self.generator.generate_course_for_competence(
                formation_code, module_data, comp, notes_formateur)
            all_content.append(course)
            all_content.append("\n" + "="*50 + "\n")

        full_content = "\n".join(all_content)
        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        emoji = FORMATION_EMOJIS.get(formation_code, "📚")

        # Créer l'embed principal
        embed = discord.Embed(
            title=f"{emoji} {module_data['titre']} | {formation_code}",
            description=f"**{formation_data.get('nom', formation_code)}** — Module complet\n"
                       f"**{len(module_data.get('competences', []))}** compétence(s) • "
                       f"**{module_data.get('heures', '?')}h** de formation",
            color=color,
        )
        embed.set_footer(text="Ambulance Assistance Marseille — Service Formation")

        channel = interaction.channel
        if isinstance(channel, discord.TextChannel):
            msg = await channel.send(embed=embed)
            thread = await msg.create_thread(
                name=f"📚 {module_data['titre']} | {formation_code}"[:100],
                auto_archive_duration=10080,
            )

            # Envoyer le contenu du module en parties
            chunks = self._split_content(full_content, 2000)
            for i, chunk in enumerate(chunks):
                part_embed = discord.Embed(description=chunk, color=color)
                part_embed.set_footer(text=f"Partie {i+1}/{len(chunks)} | {formation_data.get('nom', '')}")
                await thread.send(embed=part_embed)

            # Message de bienvenue
            await thread.send(
                f"📚 Module complet envoyé ! Utilisez `/valider` pour marquer chaque partie comme suivie."
            )

            await interaction.followup.send(
                f"✅ Module complet envoyé ! Fil : {thread.mention}",
                ephemeral=True
            )

    @app_commands.command(name="liste_formations", description="[ADMIN] Voir le référentiel complet")
    @app_commands.choices(
        formation=[
            app_commands.Choice(name="🚑 DEA", value="DEA"),
            app_commands.Choice(name="🏥 Auxiliaire", value="AA"),
            app_commands.Choice(name="⚕️ IPA", value="IPA"),
            app_commands.Choice(name="💉 IADE", value="IADE"),
            app_commands.Choice(name="🩺 IDE", value="IDE"),
            app_commands.Choice(name="📖 Toutes", value="ALL"),
        ]
    )
    async def liste_formations(self, interaction: discord.Interaction,
                                formation: app_commands.Choice[str] = None):
        """Affiche le référentiel complet d'une formation"""

        if formation and formation.value == "ALL":
            # Vue globale de toutes les formations
            embed = discord.Embed(
                title="📖 Référentiels de Formation",
                description="Ambulance Assistance Marseille — Vue d'ensemble",
                color=0x2ECC71,
            )
            for code, data in self.generator.formations_data.items():
                emoji = FORMATION_EMOJIS.get(code, "📚")
                nb_modules = len(data.get("modules", []))
                total_heures = sum(m.get("heures", 0) for m in data.get("modules", []))
                embed.add_field(
                    name=f"{emoji} {code} — {data.get('nom', '')}",
                    value=f"{nb_modules} modules • {total_heures}h total",
                    inline=False
                )
            await interaction.response.send_message(embed=embed)
            return

        if not formation:
            await interaction.response.send_message(
                "Utilisez `/liste_formations formation:DEA` pour voir le détail.", ephemeral=True)
            return

        formation_code = formation.value
        formation_data = self.generator.formations_data.get(formation_code)
        if not formation_data:
            await interaction.response.send_message("❌ Formation introuvable.", ephemeral=True)
            return

        color = FORMATION_COLORS.get(formation_code, 0x3498DB)
        emoji = FORMATION_EMOJIS.get(formation_code, "📚")

        embed = discord.Embed(
            title=f"{emoji} {formation_data.get('nom', formation_code)}",
            description=formation_data.get("description", ""),
            color=color,
        )

        for module in formation_data.get("modules", []):
            nb_comp = len(module.get("competences", []))
            field_value = f"**{module.get('heures', '?')}h** • {nb_comp} compétence(s)\n"
            for comp in module.get("competences", []):
                field_value += f"`{comp['id']}` {comp['titre'][:50]}\n"
            embed.add_field(
                name=f"{module['id']} — {module['titre'][:80]}",
                value=field_value[:1024],
                inline=False
            )

        embed.set_footer(text="Utilisez /envoyer_cours pour générer un cours détaillé")
        await interaction.response.send_message(embed=embed)

    def _split_content(self, content: str, max_length: int = 2000) -> list:
        """Découpe le contenu en morceaux de taille maximale"""
        chunks = []
        while len(content) > max_length:
            # Chercher un saut de ligne proche de la limite
            split_at = content.rfind("\n", 0, max_length)
            if split_at == -1:
                split_at = max_length
            chunks.append(content[:split_at])
            content = content[split_at:].strip()
        if content:
            chunks.append(content)
        return chunks


async def setup(bot: commands.Bot):
    await bot.add_cog(AdminCog(bot))
