# 🚑 Bot Formations — Ambulance Assistance Marseille

Bot Discord complet de gestion des formations médicales pour **Ambulance Assistance Marseille**.

## 📋 Formations couvertes

| Formation | Description | Modules |
|-----------|-------------|---------|
| 🚑 **DEA** | Diplôme d'État d'Ambulancier | 10 modules |
| 🏥 **Auxiliaire Ambulancier** | Complément au DEA | 4 modules |
| ⚕️ **IPA Soins d'Urgence** | Infirmier Pratique Avancée | 4 modules |
| 💉 **IADE** | Infirmier Anesthésiste Diplômé d'État | 5 modules |
| 🩺 **IDE Soins d'Urgence** | Infirmier Diplômé d'État Urgences | 5 modules |

## ✨ Fonctionnalités

### 🔐 Commandes Admin
- **`/envoyer_cours`** — Envoie un cours généré automatiquement dans un fil dédié avec tags
- **`/envoyer_tout_module`** — Envoie tous les cours d'un module complet
- **`/liste_formations`** — Affiche le référentiel complet d'une formation
- **`/setup_serveur`** — Configure automatiquement le serveur (canaux, rôles)
- **`/creer_forum_cours`** — Crée un forum avec tags pour organiser les cours

### 📚 Commandes Apprenants
- **`/rechercher_cours`** — Recherche un cours par mot-clé
- **`/cours_disponibles`** — Liste tous les cours avec tags
- **`/quiz`** — Quiz interactif avec boutons
- **`/inscription`** — S'inscrire à une formation
- **`/ma_progression`** — Voir son avancement
- **`/valider`** — Marquer un cours comme suivi

### 📊 Suivi & Statistiques
- **`/stats_formation`** — Statistiques par formation
- **`/leaderboard`** — Classement des apprenants

## 🎓 Comment ça fonctionne ?

### Flux de cours (Admin)

1. **L'admin choisit** : formation → module → compétence/aptitude/méthode
2. **Le bot génère** automatiquement un cours complet avec :
   - 📖 Contenu théorique adapté au domaine
   - 🎯 Objectifs pédagogiques
   - 🎬 Vidéos YouTube explicatives
   - 🔑 Points clés à retenir
   - 📋 Protocoles et étapes
   - ⚠️ Erreurs fréquentes à éviter
   - 📌 Notes personnalisées du formateur
3. **Un fil (thread) est créé** avec le cours et les tags appropriés
4. **Les apprenants** peuvent poser des questions, faire le quiz, valider le cours

### Structure d'un cours généré

```
📚 [TITRE DU COURS]
━━━━━━━━━━━━━━━━━━━━━━━━
🎯 OBJECTIFS PÉDAGOGIQUES
   ✅ Maîtriser : méthode 1, méthode 2...

📖 CONTENU THÉORIQUE
   • Points clés du domaine
   • Signes d'alerte
   • Conduite à tenir

🔑 POINTS CLÉS À RETENIR
   ⚠️ Point important 1
   ⚠️ Point important 2

📌 NOTE DU FORMATEUR
   Message personnalisé de l'admin

🎬 VIDÉOS COMPLÉMENTAIRES
   ▶️ [Titre vidéo](lien YouTube)

━━━━━━━━━━━━━━━━━━━━━━━━
Ambulance Assistance Marseille — Service Formation
```

## 🚀 Installation

### Prérequis
- Python 3.10+
- Un bot Discord créé sur [discord.com/developers](https://discord.com/developers)

### Étapes

```bash
# 1. Cloner / copier le projet
cd aa-marseille-bot

# 2. Installer les dépendances
pip install -r requirements.txt

# 3. Configurer le token
cp .env.example .env
# Éditer .env avec votre token Discord

# 4. Lancer le bot
python bot.py
```

### Configuration Discord

1. Allez sur [discord.com/developers/applications](https://discord.com/developers/applications)
2. Créez une nouvelle application
3. Allez dans "Bot" → Activez "Message Content Intent" et "Server Members Intent"
4. Copiez le token dans `.env`
5. Invitez le bot sur votre serveur avec les permissions :
   - Lire les messages
   - Envoyer des messages
   - Créer des threads
   - Gérer les threads
   - Intégrer les liens
   - Ajouter des réactions

## 📁 Structure du projet

```
aa-marseille-bot/
├── bot.py                  # Point d'entrée principal
├── config.py               # Configuration (couleurs, emojis, tags)
├── requirements.txt        # Dépendances Python
├── .env.example            # Template de configuration
├── data/
│   ├── dea.json            # Référentiel DEA
│   ├── auxiliaire.json     # Référentiel Auxiliaire
│   ├── ipa.json            # Référentiel IPA
│   ├── iade.json           # Référentiel IADE
│   └── ide_urgence.json    # Référentiel IDE Urgence
├── cogs/
│   ├── setup.py            # Configuration serveur
│   ├── admin.py            # Commandes admin
│   ├── courses.py          # Consultation & quiz
│   └── progress.py         # Suivi progression
└── utils/
    ├── course_generator.py # Générateur de cours
    └── database.py         # Base de données SQLite
```

## 🎬 Vidéos YouTube

Chaque cours inclut des vidéos YouTube explicatives intégrées. Les vidéos couvrent :
- Anatomie et physiologie
- Techniques de secours
- Pharmacologie d'urgence
- Protocoles de soins
- Ergonomie et manutention

## 🏷️ Système de tags

Les cours sont automatiquement tagués avec :

| Tag | Emoji | Description |
|-----|-------|-------------|
| theorie | 📖 | Contenu théorique |
| pratique | 🔧 | Exercices pratiques |
| urgent | 🚨 | Situations d'urgence |
| protocole | 📑 | Protocoles officiels |
| securite | 🛡️ | Sécurité |
| communication | 💬 | Communication |
| pharmacologie | 💊 | Médicaments |
| anatomie | 🫀 | Anatomie |
| hygiene | 🧼 | Hygiène |
| ergonomie | 🏋️ | Ergonomie |

## 🔧 Personnalisation

### Modifier les données de formation
Les fichiers JSON dans `data/` contiennent le référentiel. Vous pouvez :
- Ajouter des modules
- Modifier les aptitudes et méthodes
- Changer les liens YouTube

### Ajouter des formations
1. Créer un nouveau fichier JSON dans `data/`
2. L'ajouter dans `cogs/admin.py` et `cogs/courses.py` dans la section `_load_formations`
3. Ajouter les choix dans les commandes `@app_commands.choices`

### Modifier les templates de cours
Le fichier `utils/course_generator.py` contient tous les templates de génération de cours.

## 📝 Licence

Projet interne — Ambulance Assistance Marseille © 2026
