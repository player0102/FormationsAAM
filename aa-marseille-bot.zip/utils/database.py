"""
Base de données - Suivi de progression des formations
Ambulance Assistance Marseille
"""

import aiosqlite
import os
from typing import Optional


class FormationDatabase:
    """Gestion de la base de données pour le suivi des formations"""

    def __init__(self, db_path: str = "data/formations.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)

    async def init_db(self):
        """Initialise la base de données et les tables"""
        async with aiosqlite.connect(self.db_path) as db:
            # Table des utilisateurs
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    formation_code TEXT,
                    date_inscription TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Table des cours suivis
            await db.execute("""
                CREATE TABLE IF NOT EXISTS cours_suivis (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    formation_code TEXT NOT NULL,
                    module_id TEXT NOT NULL,
                    competence_id TEXT,
                    aptitude_id TEXT,
                    methode TEXT,
                    cours_type TEXT NOT NULL,
                    date_completion TEXT DEFAULT CURRENT_TIMESTAMP,
                    note TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(user_id)
                )
            """)

            # Table des cours envoyés par les admins
            await db.execute("""
                CREATE TABLE IF NOT EXISTS cours_envoyes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    admin_id INTEGER NOT NULL,
                    formation_code TEXT NOT NULL,
                    module_id TEXT NOT NULL,
                    competence_id TEXT,
                    aptitude_id TEXT,
                    methode TEXT,
                    cours_type TEXT NOT NULL,
                    thread_id INTEGER,
                    message_id INTEGER,
                    channel_id INTEGER,
                    date_envoi TEXT DEFAULT CURRENT_TIMESTAMP,
                    extra_notes TEXT
                )
            """)

            # Table des quiz et évaluations
            await db.execute("""
                CREATE TABLE IF NOT EXISTS evaluations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    formation_code TEXT NOT NULL,
                    module_id TEXT NOT NULL,
                    score INTEGER,
                    total INTEGER,
                    date_evaluation TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(user_id)
                )
            """)

            await db.commit()

    async def register_user(self, user_id: int, username: str, formation_code: str = None):
        """Inscrit un utilisateur"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT OR REPLACE INTO users (user_id, username, formation_code)
                VALUES (?, ?, ?)
            """, (user_id, username, formation_code))
            await db.commit()

    async def record_cours_suivi(self, user_id: int, formation_code: str,
                                  module_id: str, competence_id: str = None,
                                  aptitude_id: str = None, methode: str = None,
                                  cours_type: str = "aptitude"):
        """Enregistre qu'un utilisateur a suivi un cours"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO cours_suivis (user_id, formation_code, module_id, 
                    competence_id, aptitude_id, methode, cours_type)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, formation_code, module_id, competence_id,
                  aptitude_id, methode, cours_type))
            await db.commit()

    async def record_cours_envoye(self, admin_id: int, formation_code: str,
                                   module_id: str, cours_type: str,
                                   thread_id: int = None, message_id: int = None,
                                   channel_id: int = None,
                                   competence_id: str = None,
                                   aptitude_id: str = None,
                                   methode: str = None,
                                   extra_notes: str = None):
        """Enregistre un cours envoyé par un admin"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO cours_envoyes (admin_id, formation_code, module_id,
                    competence_id, aptitude_id, methode, cours_type,
                    thread_id, message_id, channel_id, extra_notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (admin_id, formation_code, module_id, competence_id,
                  aptitude_id, methode, cours_type, thread_id, message_id,
                  channel_id, extra_notes))
            await db.commit()

    async def get_user_progression(self, user_id: int, formation_code: str = None) -> dict:
        """Récupère la progression d'un utilisateur"""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row

            if formation_code:
                cursor = await db.execute("""
                    SELECT module_id, competence_id, aptitude_id, methode, cours_type
                    FROM cours_suivis WHERE user_id = ? AND formation_code = ?
                """, (user_id, formation_code))
            else:
                cursor = await db.execute("""
                    SELECT module_id, competence_id, aptitude_id, methode, cours_type, formation_code
                    FROM cours_suivis WHERE user_id = ?
                """, (user_id,))

            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def get_stats_formation(self, formation_code: str) -> dict:
        """Récupère les statistiques d'une formation"""
        async with aiosqlite.connect(self.db_path) as db:
            # Nombre d'utilisateurs inscrits
            cursor = await db.execute("""
                SELECT COUNT(*) FROM users WHERE formation_code = ?
            """, (formation_code,))
            nb_users = (await cursor.fetchone())[0]

            # Nombre de cours envoyés
            cursor = await db.execute("""
                SELECT COUNT(*) FROM cours_envoyes WHERE formation_code = ?
            """, (formation_code,))
            nb_cours = (await cursor.fetchone())[0]

            return {"inscrits": nb_users, "cours_envoyes": nb_cours}

    async def get_cours_envoyes(self, formation_code: str = None) -> list:
        """Récupère la liste des cours envoyés"""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row

            if formation_code:
                cursor = await db.execute("""
                    SELECT * FROM cours_envoyes WHERE formation_code = ?
                    ORDER BY date_envoi DESC
                """, (formation_code,))
            else:
                cursor = await db.execute("""
                    SELECT * FROM cours_envoyes ORDER BY date_envoi DESC
                """)

            rows = await cursor.fetchall()
            return [dict(row) for row in rows]
