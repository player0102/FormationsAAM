"""
Générateur de cours - Ambulance Assistance Marseille
Génère automatiquement des cours complets pour chaque aptitude/compétence/méthode
"""

import random
from typing import Optional


class CourseGenerator:
    """Génère des cours complets à partir du référentiel"""

    # Templates de cours selon le type
    TEMPLATES = {
        "aptitude": {
            "intro": [
                "Cette leçon porte sur **{titre}**. Elle est essentielle dans la formation **{formation}**.",
                "Bienvenue dans ce cours dédié à **{titre}** ! Ce module fait partie du référentiel **{formation}**.",
                "Voici le cours complet sur **{titre}**, compétence fondamentale pour tout professionnel de santé formé à **{formation}**.",
            ],
            "objectifs": [
                "À l'issue de cette leçon, vous serez capable de :",
                "Objectifs pédagogiques de ce cours :",
                "Compétences visées après cette leçon :",
            ],
            "conclusion": [
                "Vous avez maintenant les bases théoriques et pratiques pour maîtriser **{titre}**. N'hésitez pas à revoir les vidéos proposées et à poser vos questions dans ce fil.",
                "Ce cours est terminé. Révisez régulièrement les points clés et pratiquez en situation réelle sous supervision. Bonne formation !",
                "Fin de cette leçon. L'équipe pédagogique d'Ambulance Assistance Marseille reste disponible pour toute question.",
            ],
        },
        "competence": {
            "intro": [
                "Ce cours approfondit la compétence **{titre}** du référentiel **{formation}**.",
                "Nous abordons ici la compétence **{titre}**, un pilier de la formation **{formation}**.",
                "Bienvenue dans ce module sur **{titre}**. Ce contenu est issu du référentiel **{formation}** d'Ambulance Assistance Marseille.",
            ],
            "objectifs": [
                "À la fin de ce module, vous devrez maîtriser :",
                "Les objectifs de ce module de compétence sont :",
                "Savoir-faire attendus à l'issue de cette compétence :",
            ],
            "conclusion": [
                "La compétence **{titre}** est maintenant acquise. Continuez à vous entraîner et à échanger avec vos formateurs.",
                "Module terminé. Notez vos points forts et axes d'amélioration pour la validation finale.",
                "Fin du module. Pensez à remplir votre fiche d'auto-évaluation avant de passer au suivant.",
            ],
        },
        "methode": {
            "intro": [
                "Cette fiche pratique présente la méthode **{titre}**.",
                "Voici le protocole détaillé pour **{titre}**. Suivez chaque étape avec attention.",
                "Fiche technique : **{titre}** — à connaître par cœur pour vos interventions.",
            ],
            "objectifs": [
                "Points clés à retenir :",
                "Étapes essentielles :",
                "Éléments critiques du protocole :",
            ],
            "conclusion": [
                "Retenez bien les étapes de **{titre}**. En situation réelle, la rigueur et la méthode font la différence.",
                "Cette méthode doit être maîtrisée avant toute intervention autonome. Révisez et pratiquez !",
                "Protocole **{titre}** terminé. Testez vos connaissances avec le quiz associé quand disponible.",
            ],
        },
    }

    # Contenu thématique par domaine
    CONTENU_PAR_DOMAINE = {
        "pathologies": {
            "signes_alerte": [
                "• **Tachycardie** (>100 bpm) : peut indiquer douleur, hypovolémie, stress",
                "• **Bradycardie** (<60 bpm) : attention aux malaises vagaux, troubles de conduction",
                "• **Hypotension** (<90 mmHg) : risque de choc, nécessite remplissage",
                "• **Hypertension** (>180 mmHg) : risque AVC, urgence thérapeutique",
                "• **Saturation O2** (<94%) : détresse respiratoire, oxygénothérapie immédiate",
                "• **Glycémie** (<0.70 g/L ou >3 g/L) : urgence métabolique",
                "• **Température** (>38.5°C ou <35°C) : infection sévère ou hypothermie",
            ],
            "conduite_tenir": [
                "1. Sécuriser la scène et le patient",
                "2. Évaluation ABCDE",
                "3. Mise en condition (PLS, demi-assise selon cas)",
                "4. Monitoring des constantes vitales",
                "5. Alertes SAMU/Centre 15 si nécessaire",
                "6. Transport adapté vers la structure appropriée",
                "7. Transmission ciblée à l'équipe d'accueil",
            ],
        },
        "hygiene": {
            "lavage_mains": [
                "• **Lavage simple** : eau + savon pendant 30 secondes minimum",
                "• **Friction SHA** : solution hydro-alcoolique, 30 secondes, mains sèches visibles",
                "• **Lavage antiseptique** : savon antiseptique, temps de contact 1 minute",
                "• **Moments clés** : avant/après contact patient, après retrait gants, avant soin",
            ],
            "dasri": [
                "• **DASRI piquants/coupants** → conteneur jaune rigide",
                "• **DASRI mous** → sac jaune spécifique",
                "• **Déchets non souillés** → ordures ménagères",
                "• **Remplissage** : jamais plus des 2/3 du contenant",
                "• **Élimination** : selon protocole de l'établissement",
            ],
        },
        "ergonomie": {
            "manutention": [
                "• **Dos droit** : toujours garder le dos le plus droit possible",
                "• **Jambes fléchies** : utiliser la force des jambes, pas du dos",
                "• **Charge proche du corps** : réduire le bras de levier",
                "• **Communication** : toujours communiquer avec son équipier",
                "• **Aides techniques** : privilégier drap de glissement, planche, fauteuil",
            ],
        },
        "communication": {
            "sbar": [
                "• **S - Situation** : 'Je vous appelle concernant M. X, chambre 12'",
                "• **B - Background** : 'Antécédents, contexte actuel'",
                "• **A - Assessment** : 'Ce que j'évalue / constate maintenant'",
                "• **R - Recommendation** : 'Ce que je recommande / ce dont j'ai besoin'",
            ],
            "transmissions": [
                "• Identité du patient",
                "• Motif d'appel / de transport",
                "• Constantes vitales relevées",
                "• Soins réalisés pendant le transport",
                "• Évolution pendant le trajet",
                "• Éléments transmis au régulateur SAMU",
            ],
        },
        "pharmacologie": {
            "medicaments_urgence": [
                "• **Adrénaline** : anaphylaxie, ACR — 0.3-1 mg selon indication",
                "• **Amiodarone** : troubles du rythme — 300 mg en bolus ACR",
                "• **Morphine** : douleur sévère — titration IV 2-3 mg toutes les 5 min",
                "• **Midazolam** : sédation, convulsions — 5 mg IM ou 0.05 mg/kg IV",
                "• **Naloxone** : overdose opiacés — 0.4 mg IV, répétable",
                "• **Glucagon** : hypoglycémie sévère — 1 mg IM/SC",
                "• **Salbutamol** : bronchospasme — nébulisation 5 mg",
            ],
        },
        "anatomie": {
            "systemes": [
                "• **Système cardiovasculaire** : cœur, vaisseaux, circulation sanguine",
                "• **Système respiratoire** : voies aériennes, poumons, échanges gazeux",
                "• **Système nerveux** : cerveau, moelle épinière, nerfs périphériques",
                "• **Système digestif** : tube digestif, foie, pancréas",
                "• **Système urinaire** : reins, voies excrétrices",
                "• **Système musculo-squelettique** : os, articulations, muscles",
            ],
        },
    }

    def __init__(self):
        self.formations_data = {}

    def load_formation(self, code: str, data: dict):
        """Charge les données d'une formation"""
        self.formations_data[code] = data

    def generate_course_for_aptitude(self, formation_code: str, module_data: dict,
                                      competence_data: dict, aptitude_data: dict,
                                      extra_notes: str = "") -> str:
        """Génère un cours complet pour une aptitude"""
        tmpl = self.TEMPLATES["aptitude"]
        titre = aptitude_data["titre"]
        formation = self.formations_data.get(formation_code, {}).get("nom", formation_code)

        sections = []

        # En-tête
        header = random.choice(tmpl["intro"]).format(titre=titre, formation=formation)
        sections.append(header)
        sections.append("---")

        # Objectifs
        sections.append(f"**🎯 OBJECTIFS PÉDAGOGIQUES**")
        sections.append(random.choice(tmpl["objectifs"]))
        for methode in aptitude_data.get("methodes", []):
            sections.append(f"✅ Maîtriser : **{methode}**")
        sections.append("")

        # Contenu théorique
        sections.append(f"**📖 CONTENU THÉORIQUE**")
        sections.append(f"### {titre}")
        sections.append("")

        # Contenu contextuel basé sur les méthodes
        contenu_genere = self._generate_contextual_content(aptitude_data.get("methodes", []))
        sections.append(contenu_genere)
        sections.append("")

        # Points clés
        sections.append(f"**🔑 POINTS CLÉS À RETENIR**")
        points = self._generate_key_points(titre, aptitude_data.get("methodes", []))
        for p in points:
            sections.append(f"⚠️ {p}")
        sections.append("")

        # Notes admin
        if extra_notes:
            sections.append(f"**📌 NOTE DU FORMATEUR**")
            sections.append(extra_notes)
            sections.append("")

        # Vidéos
        sections.append(f"**🎬 VIDÉOS COMPLÉMENTAIRES**")
        videos = competence_data.get("videos", [])
        if videos:
            for v in videos:
                sections.append(f"▶️ [{v['titre']}]({v['url']})")
        else:
            sections.append("_Aucune vidéo supplémentaire pour ce cours._")
        sections.append("")

        # Conclusion
        sections.append("---")
        sections.append(random.choice(tmpl["conclusion"]).format(titre=titre))
        sections.append("")
        sections.append("_Ambulance Assistance Marseille — Service Formation_")

        return "\n".join(sections)

    def generate_course_for_competence(self, formation_code: str, module_data: dict,
                                        competence_data: dict, extra_notes: str = "") -> str:
        """Génère un cours complet pour une compétence"""
        tmpl = self.TEMPLATES["competence"]
        titre = competence_data["titre"]
        formation = self.formations_data.get(formation_code, {}).get("nom", formation_code)

        sections = []

        # En-tête
        header = random.choice(tmpl["intro"]).format(titre=titre, formation=formation)
        sections.append(header)
        sections.append("---")

        # Objectifs
        sections.append(f"**🎯 OBJECTIFS DU MODULE**")
        sections.append(random.choice(tmpl["objectifs"]))
        for apt in competence_data.get("aptitudes", []):
            sections.append(f"✅ {apt['titre']}")
        sections.append("")

        # Contenu structuré par aptitude
        sections.append(f"**📖 CONTENU DÉTAILLÉ**")
        sections.append("")

        for apt in competence_data.get("aptitudes", []):
            sections.append(f"### 💪 {apt['titre']}")
            contenu = self._generate_contextual_content(apt.get("methodes", []))
            sections.append(contenu)
            sections.append("")

            sections.append("**Méthodes associées :**")
            for m in apt.get("methodes", []):
                sections.append(f"• {m}")
            sections.append("")

        # Vidéos
        sections.append(f"**🎬 VIDÉOS DE RÉFÉRENCE**")
        videos = competence_data.get("videos", [])
        if videos:
            for v in videos:
                sections.append(f"▶️ [{v['titre']}]({v['url']})")
        else:
            sections.append("_Aucune vidéo pour ce module._")
        sections.append("")

        # Notes admin
        if extra_notes:
            sections.append(f"**📌 NOTE DU FORMATEUR**")
            sections.append(extra_notes)
            sections.append("")

        # Conclusion
        sections.append("---")
        sections.append(random.choice(tmpl["conclusion"]).format(titre=titre))
        sections.append("")
        sections.append("_Ambulance Assistance Marseille — Service Formation_")

        return "\n".join(sections)

    def generate_course_for_methode(self, formation_code: str, module_data: dict,
                                     competence_data: dict, aptitude_data: dict,
                                     methode: str, extra_notes: str = "") -> str:
        """Génère une fiche pratique pour une méthode spécifique"""
        tmpl = self.TEMPLATES["methode"]
        titre = methode

        sections = []

        # En-tête
        header = random.choice(tmpl["intro"]).format(titre=titre)
        sections.append(header)
        sections.append("---")

        # Contexte
        sections.append(f"**📋 CONTEXTE**")
        sections.append(f"Cette méthode s'inscrit dans l'aptitude **{aptitude_data['titre']}** "
                       f"du module **{module_data['titre']}**.")
        sections.append("")

        # Contenu principal
        sections.append(f"**📖 DÉVELOPPEMENT**")
        sections.append(f"### Protocole : {titre}")
        sections.append("")

        contenu = self._generate_contextual_content_single(methode)
        sections.append(contenu)
        sections.append("")

        # Étapes
        sections.append(f"**📝 ÉTAPES OPÉRATIONNELLES**")
        etapes = self._generate_etapes(methode)
        for i, etape in enumerate(etapes, 1):
            sections.append(f"{i}. {etape}")
        sections.append("")

        # Erreurs fréquentes
        sections.append(f"**⚠️ ERREURS FRÉQUENTES À ÉVITER**")
        erreurs = self._generate_erreurs(methode)
        for e in erreurs:
            sections.append(f"❌ {e}")
        sections.append("")

        # Vidéos
        sections.append(f"**🎬 VIDÉO DÉMONSTRATIVE**")
        videos = competence_data.get("videos", [])
        if videos:
            for v in videos:
                sections.append(f"▶️ [{v['titre']}]({v['url']})")
        sections.append("")

        # Notes admin
        if extra_notes:
            sections.append(f"**📌 NOTE DU FORMATEUR**")
            sections.append(extra_notes)
            sections.append("")

        # Conclusion
        sections.append("---")
        sections.append(random.choice(tmpl["conclusion"]).format(titre=titre))
        sections.append("")
        sections.append("_Ambulance Assistance Marseille — Service Formation_")

        return "\n".join(sections)

    def _generate_contextual_content(self, methodes: list) -> str:
        """Génère du contenu contextuel basé sur les méthodes"""
        all_content = []

        # Mapping mots-clés vers contenu
        keyword_map = {
            "constantes": "pathologies",
            "signes": "pathologies",
            "hygiène": "hygiene",
            "lavage": "hygiene",
            "DASRI": "hygiene",
            "manutention": "ergonomie",
            "dos": "ergonomie",
            "SBAR": "communication",
            "transmission": "communication",
            "pharmacologie": "pharmacologie",
            "médicament": "pharmacologie",
            "anatomie": "anatomie",
            "physiologie": "anatomie",
        }

        domaines_utilises = set()
        for methode in methodes:
            methode_lower = methode.lower()
            for keyword, domaine in keyword_map.items():
                if keyword.lower() in methode_lower:
                    domaines_utilises.add(domaine)
                    break

        # Si aucun domaine identifié, utiliser pathologies par défaut
        if not domaines_utilises:
            domaines_utilises = {"pathologies"}

        for domaine in domaines_utilises:
            contenu = self.CONTENU_PAR_DOMAINE.get(domaine, {})
            for key, items in contenu.items():
                selected = items[:min(len(items), 5)]
                all_content.extend(selected)

        return "\n".join(all_content) if all_content else "Contenu spécifique à cette méthode — se référer aux vidéos ci-dessous."

    def _generate_contextual_content_single(self, methode: str) -> str:
        """Génère du contenu pour une méthode unique"""
        contenu = self._generate_contextual_content([methode])
        if contenu == "Contenu spécifique à cette méthode — se référer aux vidéos ci-dessous.":
            return f"La méthode **{methode}** est une technique fondamentale à maîtriser dans le cadre de votre formation. " \
                   f"Elle nécessite une pratique régulière et une connaissance approfondie du protocole associé.\n\n" \
                   f"**Définition :** {methode} désigne l'ensemble des gestes et procédures standardisés " \
                   f"permettant d'assurer la sécurité du patient et du professionnel.\n\n" \
                   f"**Indications :** Cette méthode est indiquée dans toutes les situations relevant de la compétence associée.\n\n" \
                   f"**Contre-indications :** Respecter les protocoles spécifiques et les contre-indications éventuelles."
        return contenu

    def _generate_key_points(self, titre: str, methodes: list) -> list:
        """Génère des points clés pour l'aptitude"""
        points = [
            f"Toujours évaluer la situation avant d'agir sur {titre.lower()}.",
            "La sécurité du patient et du professionnel est la priorité absolue.",
            "En cas de doute, alerter le régulateur SAMU (Centre 15).",
            "Documenter chaque intervention dans le dossier de transport.",
            "Travailler en équipe et communiquer clairement avec son binôme.",
        ]
        return random.sample(points, min(3, len(points)))

    def _generate_etapes(self, methode: str) -> list:
        """Génère les étapes opérationnelles d'une méthode"""
        etapes = [
            "Vérifier l'indication et l'absence de contre-indication",
            "Préparer le matériel nécessaire et vérifier son bon fonctionnement",
            "Informer le patient et obtenir son consentement si possible",
            "Réaliser la technique selon le protocole établi",
            "Surveiller les paramètres vitaux pendant et après",
            "Documenter l'intervention dans le dossier",
            "Transmettre à l'équipe relais",
        ]
        return etapes

    def _generate_erreurs(self, methode: str) -> list:
        """Génère les erreurs fréquentes à éviter"""
        erreurs = [
            "Ne pas vérifier le matériel avant l'intervention",
            "Omettre de renseigner le dossier de transport",
            "Travailler seul sans prévenir son équipier",
            "Ne pas évaluer l'évolution après la réalisation",
            "Oublier l'hygiène des mains avant et après",
        ]
        return random.sample(erreurs, min(3, len(erreurs)))

    def get_tags_for_course(self, formation_code: str, module_data: dict,
                            competence_data: dict) -> list:
        """Détermine les tags pertinents pour un cours"""
        tags = [formation_code.lower()]
        module_titre = module_data["titre"].lower()
        competence_titre = competence_data["titre"].lower()
        combined = module_titre + " " + competence_titre

        tag_keywords = {
            "theorie": ["connaissance", "biologie", "anatomie", "physiologie", "pathologie", "cadre juridique", "réglementation"],
            "pratique": ["ergonomie", "manutention", "conduite", "brancardage", "installation"],
            "urgent": ["urgence", "détresse", "réanimation", "ACR", "état de choc", " vitale"],
            "protocole": ["protocole", "transmission", "rapport", "SBAR", "procédure"],
            "securite": ["sécurité", "protection", "DASRI", "balisage"],
            "communication": ["communication", "relation", "transmission", "écoute", "SBAR"],
            "pharmacologie": ["pharmacologie", "médicament", "anesthési", "sédation"],
            "anatomie": ["anatomie", "physiologie", "biologie", "système"],
            "hygiene": ["hygiène", "lavage", "désinfection", "DASRI", "bio-nettoyage"],
            "ergonomie": ["ergonomie", "manutention", "TMS", "dos"],
        }

        for tag, keywords in tag_keywords.items():
            for kw in keywords:
                if kw in combined:
                    tags.append(tag)
                    break

        return tags
