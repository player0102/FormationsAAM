# 🛠️ SETUP COMPLET — Bot Formations AA Marseille
## Guide pas à pas de A à Z

---

## ⚡ ÉTAPE 1 : Créer le Bot Discord (5 minutes)

### 1.1 — Créer l'application
1. Allez sur 👉 **https://discord.com/developers/applications**
2. Cliquez sur **"New Application"**
3. Nom : `AA Marseille Formations`
4. Validez

### 1.2 — Activer le Bot
1. Dans le menu à gauche → **"Bot"**
2. Cliquez **"Reset Token"** → copiez le token et gardez-le précieusement
3. Activez ces 3 options :
   - ✅ **Presence Intent**
   - ✅ **Server Members Intent**
   - ✅ **Message Content Intent**
4. Cliquez **"Save Changes"**

### 1.3 — Inviter le bot sur votre serveur
1. Menu à gauche → **"OAuth2"** → **"URL Generator"**
2. Scopes à cocher :
   - ✅ `bot`
   - ✅ `applications.commands`
3. Bot Permissions à cocher :
   - ✅ **Administrator** (ou au minimum les permissions listées ci-dessous)
   
   <details>
   <summary>Permissions minimales si vous ne voulez pas Administrator</summary>
   
   - Lire les messages / Voir les salons
   - Envoyer des messages
   - Intégrer des liens
   - Ajouter des réactions
   - Créer des threads publics
   - Créer des threads privés
   - Gérer les threads
   - Envoyer des messages dans les threads
   - Lire l'historique des messages
   - Joindre les fichiers
   - Utiliser les commandes slash
   </details>

4. Copiez l'URL générée en bas → collez-la dans votre navigateur
5. Sélectionnez votre serveur Discord → **Autoriser**

---

## ⚡ ÉTAPE 2 : Installer le Bot (10 minutes)

### 2.1 — Prérequis
- **Python 3.10+** installé sur votre machine
  - Vérifier : `python --version` (ou `python3 --version`)
  - Télécharger si besoin : https://www.python.org/downloads/

### 2.2 — Récupérer le projet
Placez-vous dans le dossier `aa-marseille-bot/` :
```bash
cd aa-marseille-bot
```

### 2.3 — Installer les dépendances
```bash
pip install -r requirements.txt
```

### 2.4 — Configurer le token
```bash
# Créer le fichier de configuration
cp .env.example .env
```

Ouvrez `.env` et remplacez par votre token :
```env
DISCORD_TOKEN=MTIzNDU2Nzg5MDEyMzQ1Njc4OQ.GxYzAb.ExampleTokenHere
ADMIN_ROLE_ID=0
FORMATEUR_ROLE_ID=0
FORMATION_CHANNEL_ID=0
```

> 💡 Le token ressemble à : `MTIzNDU2...Njc4OQ.GxYzAb.aBcDeFgHiJkLmNoPqRsTuVwXyZ`

---

## ⚡ ÉTAPE 3 : Lancer le Bot

```bash
python bot.py
```

Vous devriez voir :
```
✅ Base de données initialisée
✅ Cog chargé : cogs.setup
✅ Cog chargé : cogs.admin
✅ Cog chargé : cogs.courses
✅ Cog chargé : cogs.progress
✅ Commandes slash synchronisées

╔══════════════════════════════════════════════════╗
║  🚑 Bot Formations — AA Marseille                ║
╠══════════════════════════════════════════════════╣
║  Connecté en tant que : AA Formations            ║
║  Serveurs             : 1                        ║
╚══════════════════════════════════════════════════╝
```

---

## ⚡ ÉTAPE 4 : Configurer le Serveur Discord (1 minute)

Dans Discord, tapez la commande :

```
/setup_serveur
```

Le bot va automatiquement créer :

```
📚 FORMATIONS (catégorie)
├── 📢-annonces-formations    ← Annonces générales
├── 🚑-dea                    ← Cours DEA
├── 🏥-auxiliaire             ← Cours Auxiliaire
├── ⚕️-ipa                    ← Cours IPA
├── 💉-iade                   ← Cours IADE
└── 🩺-ide-urgence            ← Cours IDE
```

Et les rôles :
- 🚑 DEA
- 🏥 Auxiliaire
- ⚕️ IPA
- 💉 IADE
- 🩺 IDE Urgence
- 👨‍🏫 Formateur

Ensuite créez le forum :
```
/creer_forum_cours
```

---

## ⚡ ÉTAPE 5 : Récupérer les IDs (pour les rôles admin)

Pour restreindre les commandes admin :

### Obtenir l'ID d'un rôle
1. Paramètres Discord → **Avancé** → Activer **"Mode Développeur"**
2. Clic droit sur un rôle → **"Copier l'ID"**
3. Mettre cet ID dans `.env` :
```env
ADMIN_ROLE_ID=1234567890123456789
FORMATEUR_ROLE_ID=9876543210987654321
```

---

## ⚡ ÉTAPE 6 : Premier cours (test)

Allez dans le canal `#🚑-dea` et tapez :

```
/envoyer_cours formation:DEA type_cours:Aptitude module_id:DEA-M1 aptitude_id:DEA-M1-C1-A1
```

Le bot va :
1. ✅ Générer le cours complet
2. ✅ Créer un fil (thread) dédié
3. ✅ Ajouter les tags automatiques
4. ✅ Intégrer les vidéos YouTube

---

## 🔄 Lancer le bot en arrière-plan (Linux/Mac)

Pour que le bot tourne 24h/24 :

```bash
# Avec nohup (simple)
nohup python bot.py &

# Ou avec screen
screen -S bot_formations
python bot.py
# Ctrl+A puis D pour détacher

# Ou avec systemd (recommandé en production)
```

### Service systemd (production)
Créez `/etc/systemd/system/aa-bot.service` :
```ini
[Unit]
Description=Bot Formations AA Marseille
After=network.target

[Service]
Type=simple
User=votre_user
WorkingDirectory=/chemin/vers/aa-marseille-bot
ExecStart=/usr/bin/python3 bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Puis :
```bash
sudo systemctl enable aa-bot
sudo systemctl start aa-bot
sudo systemctl status aa-bot
```

---

## 📋 Commande rapide de référence

| Commande | Description |
|----------|-------------|
| `/setup_serveur` | Créer canaux + rôles |
| `/creer_forum_cours` | Créer le forum avec tags |
| `/envoyer_cours` | Envoyer un cours dans un fil |
| `/envoyer_tout_module` | Envoyer tout un module |
| `/liste_formations` | Voir le référentiel |
| `/rechercher_cours` | Chercher un cours |
| `/cours_disponibles` | Lister les cours |
| `/quiz` | Lancer un quiz |
| `/inscription` | S'inscrire à une formation |
| `/ma_progression` | Voir son avancement |
| `/valider` | Valider un cours |
| `/stats_formation` | Statistiques (admin) |
| `/leaderboard` | Classement |

---

## ❓ Dépannage

| Problème | Solution |
|----------|----------|
| `LoginFailure` | Token invalide → vérifiez `.env` |
| Bot offline | Vérifiez que les 3 intents sont activés |
| Commandes non visibles | Attendez 1-2 min, ou redémarrez Discord |
| "Permissions insuffisantes" | Vérifiez les permissions du bot + rôle admin |
| Erreur SQLite | Supprimez `data/formations.db` et relancez |
