"""
🚑 Bot Formations — Ambulance Assistance Marseille
===================================================
Bot Discord de gestion des formations pour :
- DEA (Diplôme d'État d'Ambulancier)
- Auxiliaire Ambulancier
- IPA en Soins d'Urgence
- IADE (Infirmier Anesthésiste Diplômé d'État)
- IDE en Soins d'Urgence

Fonctionnalités :
- Commande admin pour envoyer des cours (aptitudes, compétences, méthodes)
- Génération automatique de cours complets par le bot
- Vidéos YouTube intégrées pour chaque cours
- Organisation en fils (threads) avec tags
- Suivi de progression des apprenants
- Quiz interactifs
"""

import discord
from discord.ext import commands
import asyncio
import os
import sys

from config import DISCORD_TOKEN, PREFIX
from utils.database import FormationDatabase


class FormationBot(commands.Bot):
    """Bot principal de formations Ambulance Assistance Marseille"""

    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True

        super().__init__(
            command_prefix=PREFIX,
            intents=intents,
            description="Bot Formations — Ambulance Assistance Marseille 🚑",
        )

        self.db = FormationDatabase()

    async def setup_hook(self):
        """Initialisation au démarrage"""
        # Initialiser la base de données
        await self.db.init_db()
        print("✅ Base de données initialisée")

        # Charger les cogs
        cogs_to_load = [
            "cogs.setup",
            "cogs.admin",
            "cogs.courses",
            "cogs.progress",
        ]

        for cog in cogs_to_load:
            try:
                await self.load_extension(cog)
                print(f"✅ Cog chargé : {cog}")
            except Exception as e:
                print(f"❌ Erreur chargement {cog} : {e}")

        # Synchroniser les commandes slash
        await self.tree.sync()
        print("✅ Commandes slash synchronisées")

    async def on_ready(self):
        """Événement appelé quand le bot est prêt"""
        print(f"")
        print(f"╔══════════════════════════════════════════════════╗")
        print(f"║  🚑 Bot Formations — Ambulance Assistance Marseille  ║")
        print(f"╠══════════════════════════════════════════════════╣")
        print(f"║  Connecté en tant que : {self.user.name:<28}║")
        print(f"║  ID                   : {self.user.id:<28}║")
        print(f"║  Serveurs             : {len(self.guilds):<28}║")
        print(f"║  Version Discord.py   : {discord.__version__:<28}║")
        print(f"╚══════════════════════════════════════════════════╝")
        print(f"")

        # Définir le statut du bot
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="Formations AA Marseille | /aide"
            ),
            status=discord.Status.online
        )

    async def on_command_error(self, ctx, error):
        """Gestion des erreurs des commandes prefix"""
        if isinstance(error, commands.CommandNotFound):
            return
        print(f"❌ Erreur commande : {error}")

    async def on_app_command_error(self, interaction: discord.Interaction, error):
        """Gestion des erreurs des commandes slash"""
        print(f"❌ Erreur commande slash : {error}")
        try:
            if interaction.response.is_done():
                await interaction.followup.send(
                    f"❌ Une erreur est survenue : {str(error)[:200]}",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    f"❌ Une erreur est survenue : {str(error)[:200]}",
                    ephemeral=True
                )
        except:
            pass


def main():
    """Point d'entrée principal"""
    bot = FormationBot()

    # Vérifier le token
    if DISCORD_TOKEN == "VOTRE_TOKEN_ICI":
        print("❌ ERREUR : Veuillez configurer votre token Discord dans le fichier .env")
        print("   Créez un fichier .env avec : DISCORD_TOKEN=votre_token_ici")
        sys.exit(1)

    # Lancer le bot
    try:
        bot.run(DISCORD_TOKEN)
    except discord.errors.LoginFailure:
        print("❌ ERREUR : Token Discord invalide. Vérifiez votre fichier .env")
        sys.exit(1)
    except Exception as e:
        print(f"❌ ERREUR : {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
