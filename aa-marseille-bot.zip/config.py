"""
Configuration du Bot Formations - Ambulance Assistance Marseille
"""
import os
from dotenv import load_dotenv

load_dotenv()

# Token Discord
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "VOTRE_TOKEN_ICI")

# IDs des rôles admin
ADMIN_ROLE_IDS = [
    int(os.getenv("ADMIN_ROLE_ID", "0"))
]

# IDs des rôles formateurs
FORMATEUR_ROLE_IDS = [
    int(os.getenv("FORMATEUR_ROLE_ID", "0"))
]

# Canal de formation principal
FORMATION_CHANNEL_ID = int(os.getenv("FORMATION_CHANNEL_ID", "0"))

# Préfixe des commandes
PREFIX = "!"

# Base de données
DATABASE_PATH = "data/formations.db"

# Couleurs des embeds par formation
FORMATION_COLORS = {
    "DEA": 0x2ECC71,        # Vert
    "AA": 0x3498DB,         # Bleu
    "IPA": 0x9B59B6,        # Violet
    "IADE": 0xE74C3C,       # Rouge
    "IDE": 0xF39C12,        # Orange
}

# Emojis par formation
FORMATION_EMOJIS = {
    "DEA": "🚑",
    "AA": "🏥",
    "IPA": "⚕️",
    "IADE": "💉",
    "IDE": "🩺",
}

# Emojis par type
TYPE_EMOJIS = {
    "module": "📚",
    "competence": "🎯",
    "aptitude": "💪",
    "methode": "📋",
    "video": "🎬",
    "cours": "📝",
}

# Niveaux de formation
NIVEAUX = ["DEA", "AA", "IPA", "IADE", "IDE"]

# Tags disponibles pour les cours
TAGS_COURS = {
    "theorie": {"emoji": "📖", "label": "Théorie"},
    "pratique": {"emoji": "🔧", "label": "Pratique"},
    "urgent": {"emoji": "🚨", "label": "Urgence"},
    "protocole": {"emoji": "📑", "label": "Protocole"},
    "securite": {"emoji": "🛡️", "label": "Sécurité"},
    "communication": {"emoji": "💬", "label": "Communication"},
    "pharmacologie": {"emoji": "💊", "label": "Pharmacologie"},
    "anatomie": {"emoji": "🫀", "label": "Anatomie"},
    "hygiene": {"emoji": "🧼", "label": "Hygiène"},
    "ergonomie": {"emoji": "🏋️", "label": "Ergonomie"},
}
