# 🚀 GUIDE DEPLOIEMENT : GitHub → Railway
## Bot Formations AA Marseille

---

## 📋 SOMMAIRE
1. [Partie 1 : Créer un compte GitHub](#partie-1)
2. [Partie 2 : Créer le repository](#partie-2)
3. [Partie 3 : Uploader le code](#partie-3)
4. [Partie 4 : Créer un compte Railway](#partie-4)
5. [Partie 5 : Déployer sur Railway](#partie-5)
6. [Partie 6 : Configurer le bot](#partie-6)
7. [Vérification finale](#verification)

---

## 📦 PARTIE 1 : CRÉER UN COMPTE GITHUB <a name="partie-1"></a>

### Si vous n'avez pas de compte GitHub :
1. Allez sur **https://github.com**
2. Cliquez **"Sign up"**
3. Entrez votre email, mot de passe, username
4. Vérifiez votre email
5. Connectez-vous

---

## 📁 PARTIE 2 : CRÉER LE REPOSITORY <a name="partie-2"></a>

### Étape 2.1 — Créer un nouveau repo
1. En haut à droite → cliquez sur le **"+"** → **"New repository"**
2. Remplissez :
   - **Repository name** : `aa-marseille-bot`
   - **Description** : `Bot Formations - Ambulance Assistance Marseille`
   - **Public** ou **Private** (privé recommandé)
   - ✅ **Add a README file** (optionnel, on va tout uploader)
   - **NE PAS cocher** "Add .gitignore" ni "Choose a license"
3. Cliquez **"Create repository"**

### Étape 2.2 — Notez l'URL du repo
Vous verrez une URL comme :
```
https://github.com/VOTRE-USERNAME/aa-marseille-bot.git
```
**Gardez cette URL, on en aura besoin !**

---

## 📤 PARTIE 3 : UPLOADER LE CODE <a name="partie-3"></a>

### MÉTHODE A : Via l'interface web (facile, sans Git)

#### Étape 3A.1 — Extraire le ZIP
1. Décompressez `aa-marseille-bot.zip` sur votre ordinateur
2. Ouvrez le dossier extrait

#### Étape 3A.2 — Uploader via GitHub Web
1. Sur la page de votre repo GitHub → cliquez **"Add file"** → **"Upload files"**
2. **Glissez-déposez TOUS les fichiers et dossiers** dans la zone :
   ```
   📁 cogs/
   📁 data/
   📁 utils/
   📄 .env.example
   📄 .gitignore
   📄 bot.py
   📄 config.py
   📄 Procfile
   📄 README.md
   📄 requirements.txt
   📄 runtime.txt
   📄 SETUP.md
   ```
3. En bas → **"Commit changes"**
4. Attendez que l'upload se termine (1-2 minutes)

✅ **C'est fait ! Votre code est sur GitHub.**

---

### MÉTHODE B : Via Git en ligne de commande (avancé)

```bash
# 1. Ouvrez un terminal dans le dossier du projet
cd aa-marseille-bot

# 2. Initialiser Git
git init

# 3. Ajouter tous les fichiers
git add .

# 4. Premier commit
git commit -m "Initial commit - Bot Formations AA Marseille"

# 5. Connecter au repo GitHub (remplacez VOTRE-USERNAME)
git remote add origin https://github.com/VOTRE-USERNAME/aa-marseille-bot.git

# 6. Pusher
git branch -M main
git push -u origin main
```

---

## 🚂 PARTIE 4 : CRÉER UN COMPTE RAILWAY <a name="partie-4"></a>

### Étape 4.1 — S'inscrire
1. Allez sur **https://railway.app**
2. Cliquez **"Start a New Project"** ou **"Login"**
3. Connectez-vous avec :
   - ✅ **GitHub** (recommandé)
   - Ou email/mot de passe

### Étape 4.2 — Autoriser Railway à accéder à GitHub
1. Railway va vous demander l'accès à vos repos GitHub
2. Cliquez **"Authorize Railway"**
3. Sélectionnez le repo `aa-marseille-bot` (ou "All repositories")

---

## 🎯 PARTIE 5 : DÉPLOYER SUR RAILWAY <a name="partie-5"></a>

### Étape 5.1 — Créer un nouveau projet
1. Sur Railway → **"New Project"**
2. Choisissez **"Deploy from GitHub repo"**
3. Sélectionnez **`aa-marseille-bot`**

### Étape 5.2 — Configurer le service
Railway va détecter automatiquement que c'est un projet Python.

#### Vérifiez les settings :
1. Cliquez sur le service créé
2. Onglet **"Settings"**
3. Section **"Build"** :
   - **Builder** : `Nixpacks` (par défaut, c'est bon)
4. Section **"Deploy"** :
   - **Start Command** : `python bot.py`
   - Si vide, mettez : `python bot.py`

### Étape 5.3 — Ajouter les variables d'environnement
⚠️ **TRÈS IMPORTANT** — C'est ici qu'on met le token Discord !

1. Dans votre service Railway → onglet **"Variables"**
2. Cliquez **"New Variable"**
3. Ajoutez ces variables :

| Variable | Valeur |
|----------|--------|
| `DISCORD_TOKEN` | `Votre-Token-Discord-Ici` |
| `ADMIN_ROLE_ID` | `0` (ou l'ID de votre rôle admin) |
| `FORMATEUR_ROLE_ID` | `0` (ou l'ID de votre rôle formateur) |
| `FORMATION_CHANNEL_ID` | `0` (ou l'ID du canal formation) |

#### Comment obtenir le token Discord :
1. Retournez sur **https://discord.com/developers/applications**
2. Cliquez sur votre application `AA Marseille Formations`
3. Onglet **"Bot"**
4. Cliquez **"Reset Token"** (si vous ne l'avez pas sauvegardé)
5. Copiez le token
6. Collez-le dans la variable `DISCORD_TOKEN` sur Railway

### Étape 5.4 — Déployer !
1. Retournez dans l'onglet **"Deployments"**
2. Railway va automatiquement détecter les changements et déployer
3. Attendez 2-3 minutes que le build se termine
4. Vous verrez le statut **"Success"** ✅

---

## ✅ PARTIE 6 : VÉRIFICATION FINALE <a name="verification"></a>

### Étape 6.1 — Vérifier les logs
1. Dans Railway → onglet **"Deployments"**
2. Cliquez sur le deployment actif
3. Onglet **"Logs"**
4. Vous devriez voir :
   ```
   ✅ Base de données initialisée
   ✅ Cog chargé : cogs.setup
   ✅ Cog chargé : cogs.admin
   ✅ Cog chargé : cogs.courses
   ✅ Cog chargé : cogs.progress
   ✅ Commandes slash synchronisées
   
   ╔══════════════════════════════════════════════════╗
   ║  🚑 Bot Formations — AA Marseille                ║
   ╠══════════════════════════════════════════════════╣
   ║  Connecté en tant que : AA Formations            ║
   ║  Serveurs             : 1                        ║
   ╚══════════════════════════════════════════════════╝
   ```

### Étape 6.2 — Tester sur Discord
1. Retournez sur votre serveur Discord
2. Le bot devrait être **en ligne** (point vert)
3. Tapez : `/setup_serveur`
4. Le bot devrait répondre et créer les canaux + rôles !

### Étape 6.3 — Envoyer votre premier cours
```
/envoyer_cours formation:DEA type_cours:Aptitude module_id:DEA-M1 aptitude_id:DEA-M1-C1-A1
```

🎉 **BRAVO ! Votre bot est en ligne 24h/24 !**

---

## 🔄 MISES À JOUR AUTOMATIQUES

Quand vous modifiez le code sur GitHub :
1. Faites un commit + push (via GitHub Web ou Git)
2. Railway détecte automatiquement le changement
3. Redéploie automatiquement en 1-2 minutes
4. Aucune intervention manuelle nécessaire !

---

## 💰 COÛT RAILWAY

Railway offre :
- ✅ **$5 de crédit gratuit** par mois (suffisant pour un bot Discord)
- ✅ Environ **500-750 heures** d'exécution/mois
- ✅ Pas de carte bancaire requise pour commencer

Si vous dépassez :
- Hobby Plan : **$5/mois** pour 500h
- Pro Plan : **$20/mois** pour usage illimité

Pour un bot Discord simple, le plan gratuit suffit largement !

---

## ❌ DÉPANNAGE

### Le bot ne démarre pas
1. Vérifiez les logs sur Railway → onglet "Deployments" → "Logs"
2. Vérifiez que `DISCORD_TOKEN` est bien renseigné
3. Vérifiez que les 3 intents sont activés sur Discord Developer Portal

### Erreur "ModuleNotFoundError"
```bash
# Vérifiez que requirements.txt contient bien :
discord.py>=2.3.0
python-dotenv>=1.0.0
aiohttp>=3.9.0
aiosqlite>=0.19.0
```

### Le bot se déconnecte
- Railway redémarre automatiquement les services
- Vérifiez dans les logs s'il y a des erreurs
- Si le bot crash, Railway le redémarre automatiquement

### Les commandes slash n'apparaissent pas
- Attendez 1-2 minutes (Discord met à jour les commandes globales)
- Ou redémarrez Discord (Ctrl+R)

---

## 📞 SUPPORT

- Documentation Railway : https://docs.railway.app
- Discord Railway : https://discord.gg/railway
- Documentation Discord.py : https://discordpy.readthedocs.io

---

## 🎉 FÉLICITATIONS !

Votre bot **Ambulance Assistance Marseille** est maintenant :
- ✅ Hébergé 24h/24 sur Railway
- ✅ Synchronisé avec GitHub
- ✅ Déploiement automatique à chaque push
- ✅ Gratuit (ou très peu cher)

**Bon déploiement ! 🚀**
